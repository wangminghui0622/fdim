// Copyright © 2023 OpenIM open source community. All rights reserved.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

package admin

import (
	"context"
	"fdim/pkg/db/pagination"
	"time"
)

type LimitUserLoginIP struct {
	UserID     string    `bson:"user_id"`
	IP         string    `bson:"ip"`
	CreateTime time.Time `bson:"create_time"`
}

func (LimitUserLoginIP) TableName() string {
	return "limit_user_login_ips"
}

type LimitUserLoginIPInterface interface {
	Create(ctx context.Context, ms []*LimitUserLoginIP) error
	Delete(ctx context.Context, ms []*LimitUserLoginIP) error
	Count(ctx context.Context, userID string) (uint32, error)
	Take(ctx context.Context, userID string, ip string) (*LimitUserLoginIP, error)
	Search(ctx context.Context, keyword string, pagination pagination.Pagination) (int64, []*LimitUserLoginIP, error)
}
